このフォルダは、旧「ネイティブビルド大作戦」のメモ置き場です。

現在は下記パスを正（最新版）としています。

- docs/guides/how-to-build-native/README.md
- docs/guides/how-to-build-native/追記相談.txt
- docs/guides/how-to-build-native/issues/

注意:
- 以前このフォルダにあった「追記相談.txt」の内容は、上記 guides 配下の同名ファイルに統合済みです（内容は同一）。
- 今後の更新は guides 側に集約してください。本フォルダは参照用のみに残しています。

