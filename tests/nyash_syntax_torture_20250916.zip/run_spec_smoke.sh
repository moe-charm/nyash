
#!/usr/bin/env bash
set -euo pipefail

NYASH_BIN=${NYASH_BIN:-./target/release/nyash}
BACKENDS=${BACKENDS:-"interp vm llvm"}   # choose subset: "interp vm", etc.
OUTDIR=${OUTDIR:-_out}
mkdir -p "$OUTDIR"

fail=0

run_one () {
  local file="$1"
  local mode="$2"
  local out="$OUTDIR/$(basename "$file").$mode.out"
  case "$mode" in
    interp) "$NYASH_BIN" "$file" > "$out" ;;
    vm)     "$NYASH_BIN" --backend vm "$file" > "$out" ;;
    llvm)
      # Requires LLVM features and NYASH_LLVM_OBJ_OUT env; emit and run
      local obj="$OUTDIR/nyash_llvm_temp.o"
      NYASH_LLVM_OBJ_OUT="$obj" "$NYASH_BIN" --backend llvm "$file" >/dev/null
      cc "$obj" -L crates/nyrt/target/release -Wl,--whole-archive -lnyrt -Wl,--no-whole-archive -lpthread -ldl -lm -o "$OUTDIR/app_$(basename "$file" .nyash)"
      "$OUTDIR/app_$(basename "$file" .nyash)" > "$out"
      ;;
    *) echo "Unknown mode: $mode" >&2; return 2;;
  esac
}

compare_modes () {
  local file="$1"
  local modes=($BACKENDS)
  local ref="${modes[0]}"
  for m in "${modes[@]}"; do
    run_one "$file" "$m"
  done
  local refout="$OUTDIR/$(basename "$file").$ref.out"
  for m in "${modes[@]:1}"; do
    local out="$OUTDIR/$(basename "$file").$m.out"
    if ! diff -u "$refout" "$out"; then
      echo "[DIFF] $(basename "$file") ($ref vs $m) differs" >&2
      fail=1
    fi
  done
}

main () {
  local tests=( $(ls -1 tests/syntax_torture/*.nyash 2>/dev/null || true) )
  if [ ${#tests[@]} -eq 0 ]; then
    # fallback: assume running inside this folder
    tests=( $(ls -1 ./*.nyash) )
  fi

  for t in "${tests[@]}"; do
    echo "==> $(basename "$t")"
    compare_modes "$t"
  done

  if [ $fail -ne 0 ]; then
    echo "Some tests differ across backends." >&2
    exit 1
  fi
  echo "All tests matched across selected backends."
}

main "$@"
