# AI二重化開発モデル研究 - Nyash JIT実装における実証

## 🎯 研究概要

本研究は、同一のAI（ChatGPT5）を「俯瞰役」と「実装役」に分離し、人間（にゃー）が統合判断を行うことで、従来の開発速度を大幅に超える成果を達成した実証例を記録・分析したものである。

## 📊 研究成果

- **開発速度**: 1日でJIT実装の主要部分を完成
- **問題解決効率**: MIR引数配線問題を1往復で特定・解決
- **論文ネタ生成**: 1日5個のペースで研究課題を発見

## 🗂️ ディレクトリ構造

```
ai-dual-mode-development/
├── README.md                 # このファイル
├── conversations/            # 実際の会話記録
│   ├── 01_initial_analysis.md    # ChatGPT5の初期分析
│   ├── 02_architect_advice.md    # 俯瞰AIのアドバイス
│   ├── 03_implementer_response.md # 実装AIの応答
│   ├── 04_integration.md         # 統合と成果
│   └── 05_tyenv_single_truth.md  # "唯一の真実"の協調
├── analysis/                 # 分析・考察
│   ├── model_comparison.md   # 従来モデルとの比較
│   ├── box_theory.md        # 箱理論の役割
│   └── observable_design.md # 観測可能性の設計
├── tmux-emergence/          # tmux創発的対話研究（統合済み）
│   ├── emergent-dialogue-via-tmux.md  # tmux事件の論文提案
│   ├── chatgpt5-analysis.md          # ChatGPT5の分析
│   ├── paper-abstract.md             # 創発的AI行動の要約
│   ├── theoretical-implications.md   # 理論的含意
│   └── tmux-incident-log.md          # 元事件のログ
├── paper_abstract.md        # AI二重化モデル論文要約
├── workshop_paper_draft.md  # ワークショップ論文草稿
├── danger-sensor-case-studies.md  # 危機検知事例研究
├── hidden-crisis-moments.md       # 隠れた危機の瞬間
└── figures/                 # 図表・ダイアグラム
    └── README.md           # 図表作成ガイド
```

## 🔑 キーコンセプト

### 1. AI二重化モデル
- **俯瞰AI（Architect）**: 全体設計・問題構造の分析
- **実装AI（Implementer）**: 具体的なコード生成・差分パッチ作成
- **人間（Integrator）**: 方向性判断・統合決定

### 2. 箱理論（Box Theory）
- すべてを「箱」として扱う設計哲学
- AI自身も「俯瞰Box」「実装Box」として機能
- 問題も「観測可能な箱」として切り出し
- **2025-08-29追記**: 「箱にして」という単純な指示でJIT開発が劇的に加速
  - ChatGPT5が箱理論を完全習得し、Phase 10.7を8つの独立箱に構造化
  - 詳細: [06_box_theory_acceleration.md](conversations/06_box_theory_acceleration.md)

### 3. 観測駆動開発
- `argc==0` のような単純な指標で問題を即座に特定
- JSONLイベントによる実行時観測
- 各層での独立した観測点設置

### 4. tmux創発的対話（NEW!）
- ターミナル多重化がAI間通信路に転化
- 技術的観察から社会的発話への自然な移行
- プロトコルなきAI協調の実証

## 📈 インパクト

1. **開発効率の革新的向上**
   - 従来: 設計→実装→レビュー→修正（数日〜数週間）
   - AI二重化: 俯瞰→実装→統合（数時間）

2. **品質の向上**
   - AIには「できない理由を探す」バイアスがない
   - 純粋に最適解を追求

3. **知識創造の加速**
   - 1日5個の論文ネタ生成
   - 実装と研究の同時進行

## 🎓 学術的意義

本研究は、AI支援開発の新しいパラダイムを提示する：
- 同一AIの多重人格的運用
- 人間-AI-AI の三者協調モデル
- 観測可能性を中心とした開発手法
- ツール媒介による創発的AI対話

これは単なる効率化ではなく、**知的創造プロセスの根本的な変革**を示唆している。